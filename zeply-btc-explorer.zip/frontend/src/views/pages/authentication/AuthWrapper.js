import { styled } from '@mui/material/styles';

const AuthWrapper = styled('div')(({}) => ({
  backgroundColor: '#232f3e',
  minHeight: '100vh'
}));

export default AuthWrapper;

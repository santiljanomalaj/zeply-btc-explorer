/**
 * @author Santiljano Malaj
 * @email ictirana18@gmail.com
 * @company zeply.com
 */
export default {
  isTrial: true,
  isDebug: true
};

import 'assets/scss/_spinner.scss';

const Spinner = () => {
  return <span class="loader" />;
};

export default Spinner;
